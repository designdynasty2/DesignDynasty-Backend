import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './Components/Navbar/Navbar'; // Adjust the import path
import FormBuilder from './Components/FormBuilder'; // Your form builder component
import PreviewForm from './Components/PreviewForm'; // Your preview component
import './App.css'

const App = () => {
  return (
    <Router>
      <Navbar /> {/* NavBar should be outside of Routes */}
      <Routes>
        <Route path="/" element={<FormBuilder />} />
        <Route path="/preview" element={<PreviewForm />} />
        {/* Add more routes as needed */}
      </Routes>
    </Router>
  );
};

export default App;
