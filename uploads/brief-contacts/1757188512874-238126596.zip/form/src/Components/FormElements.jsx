import React from 'react';

const FormElements = ({ handleDragStart }) => {
  return (
    <div className="form-elements">
      <h4>Drag and Drop Elements</h4>
      <div draggable onDragStart={(e) => handleDragStart(e, 'input')} className="element">Input Field</div>
      <div draggable onDragStart={(e) => handleDragStart(e, 'textarea')} className="element">Textarea</div>
      <div draggable onDragStart={(e) => handleDragStart(e, 'checkbox')} className="element">Checkbox</div>
      
      {/* New Elements */}
      <div draggable onDragStart={(e) => handleDragStart(e, 'button')} className="element">Button</div>
      <div draggable onDragStart={(e) => handleDragStart(e, 'date')} className="element">Date</div>
      <div draggable onDragStart={(e) => handleDragStart(e, 'time')} className="element">Time</div>
      <div draggable onDragStart={(e) => handleDragStart(e, 'file')} className="element">Upload File</div>
      <div draggable onDragStart={(e) => handleDragStart(e, 'hidden')} className="element">Hidden Input</div>
      <div draggable onDragStart={(e) => handleDragStart(e, 'select')} className="element">Select</div>
      <div draggable onDragStart={(e) => handleDragStart(e, 'autocomplete')} className="element">Autocomplete</div>
    </div>
  );
};

export default FormElements;
