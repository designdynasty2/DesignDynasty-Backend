import React, { useState } from 'react';
import './Navbar.css';
import Profile from '../../assets/profileimg/pngtree-avatar-icon-profile-icon-member-login-vector-isolated-png-image_1978396.jpg';
import { SettingOutlined } from '@ant-design/icons';
import { LogoutOutlined } from '@ant-design/icons';
import { Dropdown, Space } from 'antd';
import { useNavigate } from 'react-router-dom';

const items = [
  {
    key: '1',
    label: 'kumaran V',
    disabled: true,
  },
  {
    type: 'divider',
  },
  {
    key: '2',
    label: 'Profile',
    extra: '⌘P',
  },
  {
    key: '3',
    label: 'Change Password',
    extra: '⌘B',
  },
  {
    key: '4',
    label: 'Settings',
    icon: <SettingOutlined />,
    extra: '⌘S',
  },
  {
    key: '5',
    label: 'Logout',
    icon: <LogoutOutlined />,
    extra: '⌘S',
  },
];

const NavBar = () => {
    const navigate = useNavigate();

    const handleLogout = () => {
      // Clear the authentication flag and redirect to the login page
      localStorage.removeItem('isAuthenticated');
      navigate('/');
    };

  const [searchValue, setSearchValue] = useState('');

  const handleSearch = (e) => {
    setSearchValue(e.target.value);
    // Add any additional search logic here if needed
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Search submitted:', searchValue);
    // Handle search submission logic here
  };

  return (
    <div className="nav-bar">
      <h1>FORM BUILDER</h1>
      <form onSubmit={handleSubmit} className="search-form">
        <input
          type="text"
          placeholder="Search..."
          value={searchValue}
          onChange={handleSearch}
          className="search-input"
        />
        {/* <button type="submit" className="search-button">Search</button> */}
      
        {/* <button onClick={handleLogout}>Logout</button> */}

        <Dropdown
          menu={{
          items,
                }}
          >
          <a onClick={(e) => e.preventDefault()}>
          <Space>
            <div className='profile-img'>
            <img  src={Profile} alt="msicon" />
            </div>
         </Space>
         </a>
        </Dropdown>

        </form>
    </div>
  );
};

export default NavBar;
