// src/Components/Modal.js
import React from 'react';
import Modal from 'react-modal';

// Set the root element for accessibility purposes
Modal.setAppElement('#root');

const CustomModal = ({ isOpen, onRequestClose, children }) => {
    return (
        <Modal
            isOpen={isOpen}
            onRequestClose={onRequestClose}
            style={{ overlay: { zIndex: 1000 } }}
        >
            <button onClick={onRequestClose}>Close</button>
            {children}
        </Modal>
    );
};

export default CustomModal;
