// src/Components/FormEditor.js
import React, { useState } from 'react';
import './FormEditor.css'

const FormEditor = ({ element, updateElement, closeModal }) => {
  const [label, setLabel] = useState(element.label || '');
  const [placeholder, setPlaceholder] = useState(element.placeholder || '');
  const [isRequired, setIsRequired] = useState(element.required || false);
  const [validationType, setValidationType] = useState(element.validationType || 'text');

  const handleSave = () => {
    updateElement({
      ...element,
      label,
      placeholder,
      required: isRequired,
      validationType,
    });
    closeModal();
  };

  return (
    <div className="popup-page-editor">
      <div className="editor-header">
        <h4>Edit Form Element</h4>
      </div>

      <div className="editor-body">
        <div className="editor-field">
          <label>Label:</label>
          <input type="text" value={label} onChange={(e) => setLabel(e.target.value)} />
        </div>

        {element.type !== 'checkbox' && (
          <div className="editor-field">
            <label>Placeholder:</label>
            <input type="text" value={placeholder} onChange={(e) => setPlaceholder(e.target.value)} />
          </div>
        )}

        <div className="editor-field">
          <label>
            <input type="checkbox" checked={isRequired} onChange={(e) => setIsRequired(e.target.checked)} />
            Required
          </label>
        </div>

        {element.type === 'input' && (
          <div className="editor-field">
            <label>Validation Type:</label>
            <select value={validationType} onChange={(e) => setValidationType(e.target.value)}>
              <option value="text">Text</option>
              <option value="email">Email</option>
              <option value="number">Number</option>
              <option value="tel">Phone Number</option>
            </select>
          </div>
        )}
      </div>

      <div className="editor-footer">
        <button style={{ marginRight: "5px" }} onClick={closeModal} className="close-button">Close</button>
        <button onClick={handleSave} className="save-button">Save</button>
      </div>
    </div>
  );
};

export default FormEditor;
