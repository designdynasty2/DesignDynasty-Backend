// src/Components/FormBuilder.js
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import FormEditor from './FormEditor';
import { FaEdit, FaTrash, FaArrowsAlt } from 'react-icons/fa';
import './FormBuilder.css';

const FormBuilder = () => {
  const [formElements, setFormElements] = useState([]);
  const [selectedElement, setSelectedElement] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const navigate = useNavigate();

  const handleDrop = (e) => {
    e.preventDefault();
    const elementType = e.dataTransfer.getData('element');
    const newElement = {
      id: Date.now(),
      type: elementType,
      label: `${elementType.charAt(0).toUpperCase() + elementType.slice(1)}`,
      placeholder: `${elementType} placeholder`,
      required: false,
      validationType: 'text',
      options: elementType === 'select' || elementType === 'autocomplete' ? ['Option 1', 'Option 2'] : [],
    };
    setFormElements([...formElements, newElement]);
  };

  const handleDragOver = (e) => e.preventDefault();

  const handleElementClick = (id) => {
    const element = formElements.find((el) => el.id === id);
    setSelectedElement(element);
    setIsEditing(true);
  };

  const closeModal = () => setIsEditing(false);

  const updateElement = (updatedElement) => {
    setFormElements(
      formElements.map((el) => (el.id === updatedElement.id ? updatedElement : el))
    );
  };

  const removeElement = (id) => {
    setFormElements(formElements.filter((el) => el.id !== id));
  };

  const openPreview = () => {
    navigate('/preview', { state: { formElements } }); // Navigate to preview with form data
  };

  return (
    <div className="form-builder-container">
      <div className="toolbox">
        {['input', 'textarea', 'checkbox', 'button', 'date', 'time', 'file', 'select', 'autocomplete'].map((type) => (
          <div
            key={type}
            draggable
            onDragStart={(e) => e.dataTransfer.setData('element', type)}
            className="toolbox-item"
          >
            {type.charAt(0).toUpperCase() + type.slice(1)}
          </div>
        ))}
      </div>

      <div className="form-builder-area">
        {isEditing ? (
          <FormEditor
            element={selectedElement}
            updateElement={updateElement}
            closeModal={closeModal}
          />
        ) : (
          <div
            className="form-builder"
            onDrop={handleDrop}
            onDragOver={handleDragOver}
          >
            {formElements.length === 0 && (
              <h4 className="form-builder-placeholder">Drop Here to Build Form</h4>
            )}
            {formElements.map((element) => (
              <div key={element.id} className="form-element">
                <div className="element-controls">
                  <FaEdit onClick={() => handleElementClick(element.id)} className="icon edit-icon" />
                  <FaTrash onClick={() => removeElement(element.id)} className="icon trash-icon" />
                  <FaArrowsAlt className="icon drag-icon" />
                </div>
                <label className="element-label">{element.label}</label>
                {element.type === 'input' && <input placeholder={element.placeholder} required={element.required} />}
                {element.type === 'textarea' && <textarea placeholder={element.placeholder} required={element.required} />}
                {element.type === 'checkbox' && (
                  <label>
                    <input type="checkbox" required={element.required} />
                    {element.label}
                  </label>
                )}
                {element.type === 'button' && <button>{element.label}</button>}
                {element.type === 'date' && <input type="date" required={element.required} />}
                {element.type === 'time' && <input type="time" required={element.required} />}
                {element.type === 'file' && <input type="file" />}
                {element.type === 'select' && (
                  <select required={element.required}>
                    {element.options.map((opt, idx) => (
                      <option key={idx}>{opt}</option>
                    ))}
                  </select>
                )}
                {element.type === 'autocomplete' && (
                  <input
                    list={`autocomplete-${element.id}`}
                    placeholder={element.placeholder}
                    required={element.required}
                  />
                )}
              </div>
            ))}
          </div>
        )}
        <button onClick={openPreview} className="preview-button">Preview</button>
      </div>
    </div>
  );
};

export default FormBuilder;
