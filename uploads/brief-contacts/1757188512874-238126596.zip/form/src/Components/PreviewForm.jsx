// src/Components/PreviewForm.js
import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import './PreviewForm.css'; // Ensure you import your CSS

const PreviewForm = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { formElements } = location.state || { formElements: [] };

  const handleConfirm = () => {
    const jsonOutput = JSON.stringify(formElements, null, 2);
    alert(jsonOutput);
  };

  return (
    <div className="preview-form-container">
      <h2>Form Preview</h2>
      <div className="form-preview">
        {formElements.map((element) => (
          <div key={element.id} className="form-element-preview">
            <label>
              {element.label} 
              {element.required && <span className="required-asterisk">*</span>}
            </label>
            {element.type === 'input' && <input placeholder={element.placeholder} required={element.required} />}
            {element.type === 'textarea' && <textarea placeholder={element.placeholder} required={element.required} />}
            {element.type === 'checkbox' && (
              <label>
                <input type="checkbox" required={element.required} />
                {element.label}
              </label>
            )}
            {element.type === 'button' && <button>{element.label}</button>}
            {element.type === 'date' && <input type="date" required={element.required} />}
            {element.type === 'time' && <input type="time" required={element.required} />}
            {element.type === 'file' && <input type="file" />}
            {element.type === 'select' && (
              <select required={element.required}>
                {element.options.map((opt, idx) => (
                  <option key={idx}>{opt}</option>
                ))}
              </select>
            )}
            {element.type === 'autocomplete' && (
              <input
                list={`autocomplete-${element.id}`}
                placeholder={element.placeholder}
                required={element.required}
              />
            )}
          </div>
        ))}
      </div>
      <button onClick={handleConfirm} className="confirm-button">Confirm</button>
      <button onClick={() => navigate(-1)} className="back-button">Back</button>
    </div>
  );
};

export default PreviewForm;
